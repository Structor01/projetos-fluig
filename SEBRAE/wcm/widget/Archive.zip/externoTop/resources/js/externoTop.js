$(document).ready(function () {
    $('[data-menu-main]').remove();
});