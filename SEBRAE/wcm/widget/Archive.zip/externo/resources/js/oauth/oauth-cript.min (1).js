console.log('%c [v.up.0.0.1] oauth-cript.js', 'color:gray');

_keys = {
	'producao': {
		'POST': {
			api:			'/api/public/ecm/dataset/datasets',
			consumerPublic: "post",
			consumerSecret: "post-secret",
			tokenPublic: 	"6a97cca5-2040-407f-b432-a9d16d0259b5",
			tokenSecret: 	"1578347f-ea7f-4440-8f99-98821f6dfca243db23f3-05f4-42cd-ac71-c374a4df703b"
		}, 
		'GET': {
			api:			'/api/public/ecm/dataset/datasetStructure/',
			consumerPublic: "get",
			consumerSecret: "get-secret",
			tokenPublic: 	"76156377-aa73-4031-9ae6-540e0064981a",
			tokenSecret: 	"664c1392-8039-49b0-ab34-bfd795bb20f7ebb407d6-ba6f-4a09-be82-d8673c51c4ff"
		}	
	}
};