/**
 * Carrega table
 */
function carregaTable(table){
	var row = wdkAddChild(table);
}		