function SomenteNumero(e){
		var tecla=(window.event)?event.keyCode:e.which;   
		if((tecla>47 && tecla<58)) return true;
		else{
			if (tecla==8 || tecla==0) return true;
		else  return false;
		}
}


function mascara_num(obj){
	  valida_num(obj)
	  if (obj.value.match("-")){
	    mod = "-";
	  }else{
	    mod = "";
	  }
	  valor = obj.value.replace("-","");
	  valor = valor.replace(",","");
	  ///// if (valor.length >= 3){
	  /////   valor = poe_ponto_num(valor.substring(0,valor.length-2))+","+valor.substring(valor.length-2, valor.length);
	  ///// }
	  obj.value = mod+valor;
}

function poe_ponto_num(valor){
	  valor = valor.replace(/\./g,"");
	  if (valor.length > 3){
	    valores = "";
	    while (valor.length > 3){
	      valores = "."+valor.substring(valor.length-3,valor.length)+""+valores;
	      valor = valor.substring(0,valor.length-3);
	    }
	    return valor+""+valores;
	  }else{
	    return valor;
	  }
}

function valida_num(obj){
	  numeros = new RegExp("[0-9]");
	  while (!obj.value.charAt(obj.value.length-1).match(numeros)){
	    if(obj.value.length == 1 && obj.value == "-"){
	      return true;
	    }
	    if(obj.value.length >= 1){
	      obj.value = obj.value.substring(0,obj.value.length-1)
	    }else{
	      return false;
	    }
	  }
}


function mascaraData(campoData){
		  var data = campoData.value;
			if ((data.length == 2) || (data.length == 5)){ 
				data = data + '/';
				document.forms[0].data_refeicao.value = data;
				return true;              
			}
}

function mascaraData2(campoData){
		  var data = campoData.value;
			if ((data.length == 2) || (data.length == 5)){ 
				data = data + '/';
				document.forms[0].data_refeicao_1.value = data;
				return true;              
			}
}

function mascaraData3(campoData){
		  var data = campoData.value;
			if ((data.length == 2) || (data.length == 5)){ 
				data = data + '/';
				document.forms[0].data_refeicao_2.value = data;
				return true;              
			}
}

function mascaraData4(campoData){
		  var data = campoData.value;
			if ((data.length == 2) || (data.length == 5)){ 
				data = data + '/';
				document.forms[0].data_refeicao_3.value = data;
				return true;              
			}
}

function mascaraData5(campoData){
		  var data = campoData.value;
			if ((data.length == 2) || (data.length == 5)){ 
				data = data + '/';
				document.forms[0].data_refeicao_4.value = data;
				return true;              
			}
}

function mascaraData6(campoData){
		  var data = campoData.value;
			if ((data.length == 2) || (data.length == 5)){ 
				data = data + '/';
				document.forms[0].data_refeicao_5.value = data;
				return true;              
			}
}

function mascaraData7(campoData){
		  var data = campoData.value;
			if ((data.length == 2) || (data.length == 5)){ 
				data = data + '/';
				document.forms[0].data_refeicao_6.value = data;
				return true;              
			}
}
/////////////////   Calculo do Total /////////////////////////////////////////////////////////////////////////////////////////
function calcula_total() {
	calcula_cafe(0);
	calcula_almoco(0);
	calcula_jantar(0);
	calcula_ceia(0);
}

function calcula_cafe(valor){
	
	var total_soma_cafe = Number(document.getElementById("total_cafe").value);
	
	var soma_cafe = Number(document.getElementById("cafe_refeicao").value);
	var soma_cafe1 = Number(document.getElementById("cafe_refeicao_1").value);
	var soma_cafe2 = Number(document.getElementById("cafe_refeicao_2").value);
	var soma_cafe3 = Number(document.getElementById("cafe_refeicao_3").value);
	var soma_cafe4 = Number(document.getElementById("cafe_refeicao_4").value);
	var soma_cafe5 = Number(document.getElementById("cafe_refeicao_5").value);
	var soma_cafe6 = Number(document.getElementById("cafe_refeicao_6").value);
	
	total_soma_cafe = soma_cafe + soma_cafe1 + soma_cafe2 + soma_cafe3 + soma_cafe4 + soma_cafe5 + soma_cafe6;
	
	document.getElementById("total_cafe").value = total_soma_cafe;
	
}


function calcula_almoco(valor){
	
	var total_soma_almoco = Number(document.getElementById("total_almoco").value);
	
	var soma_almoco = Number(document.getElementById("almoco_refeicao").value);
	var soma_almoco1 = Number(document.getElementById("almoco_refeicao_1").value);
	var soma_almoco2 = Number(document.getElementById("almoco_refeicao_2").value);
	var soma_almoco3 = Number(document.getElementById("almoco_refeicao_3").value);
	var soma_almoco4 = Number(document.getElementById("almoco_refeicao_4").value);
	var soma_almoco5 = Number(document.getElementById("almoco_refeicao_5").value);
	var soma_almoco6 = Number(document.getElementById("almoco_refeicao_6").value);
	
	total_soma_almoco = soma_almoco + soma_almoco1 + soma_almoco2 + soma_almoco3 + soma_almoco4 + soma_almoco5 + soma_almoco6;
	
	document.getElementById("total_almoco").value = total_soma_almoco;
}

function calcula_jantar(valor){
	
	var total_soma_jantar = Number(document.getElementById("total_jantar").value);
	
	var soma_jantar = Number(document.getElementById("jantar_refeicao").value);
	var soma_jantar1 = Number(document.getElementById("jantar_refeicao_1").value);
	var soma_jantar2 = Number(document.getElementById("jantar_refeicao_2").value);
	var soma_jantar3 = Number(document.getElementById("jantar_refeicao_3").value);
	var soma_jantar4 = Number(document.getElementById("jantar_refeicao_4").value);
	var soma_jantar5 = Number(document.getElementById("jantar_refeicao_5").value);
	var soma_jantar6 = Number(document.getElementById("jantar_refeicao_6").value);
	
	total_soma_jantar = soma_jantar + soma_jantar1 + soma_jantar2 + soma_jantar3 + soma_jantar4 + soma_jantar5 + soma_jantar6;
	
	document.getElementById("total_jantar").value = total_soma_jantar;
}

function calcula_ceia(valor){
	
	var total_soma_ceia = Number(document.getElementById("total_ceia").value);
	
	var soma_ceia = Number(document.getElementById("ceia_refeicao").value);
	var soma_ceia1 = Number(document.getElementById("ceia_refeicao_1").value);
	var soma_ceia2 = Number(document.getElementById("ceia_refeicao_2").value);
	var soma_ceia3 = Number(document.getElementById("ceia_refeicao_3").value);
	var soma_ceia4 = Number(document.getElementById("ceia_refeicao_4").value);
	var soma_ceia5 = Number(document.getElementById("ceia_refeicao_5").value);
	var soma_ceia6 = Number(document.getElementById("ceia_refeicao_6").value);
	
	total_soma_ceia = soma_ceia + soma_ceia1 + soma_ceia2 + soma_ceia3 + soma_ceia4 + soma_ceia5 + soma_ceia6;
	
	document.getElementById("total_ceia").value = total_soma_ceia;
}